---
name: Feature request
about: Suggest a project improvement or new capability
title: "[Feature] "
labels: enhancement
assignees: ""
---

## Idea

Describe the feature or improvement.

## Problem It Solves

What limitation, integration issue, or user need does this address?

## Proposed Approach

If you have an implementation idea, describe it here.

## Affected Area

- [ ] Mechanical / CAD
- [ ] Electronics / power
- [ ] Controller firmware
- [ ] Android / display software
- [ ] Standalone Linux
- [ ] Documentation
- [ ] Other

## Additional Notes

Add sketches, measurements, references, or test results if useful.
