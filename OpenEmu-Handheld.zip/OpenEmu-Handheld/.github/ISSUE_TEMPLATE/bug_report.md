---
name: Bug report
about: Report a reproducible problem with project files or documentation
title: "[Bug] "
labels: bug
assignees: ""
---

## Problem

Describe what is not working.

## Affected Version / Revision

- Project release:
- Part / CAD revision:
- Device / platform:

## Steps to Reproduce

1.
2.
3.

## Expected Result

What should have happened?

## Actual Result

What happened instead?

## Additional Information

Add photos, screenshots, measurements, logs, or other useful details. Do not attach copyrighted ROMs, BIOS files, console keys, or proprietary firmware.
